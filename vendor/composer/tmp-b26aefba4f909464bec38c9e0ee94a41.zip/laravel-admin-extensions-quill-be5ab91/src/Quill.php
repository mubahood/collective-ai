<?php

namespace Jxlwqq\Quill;

use Encore\Admin\Extension;

class Quill extends Extension
{
    public $name = 'quill';

    public $views = __DIR__.'/../resources/views';

    public $assets = __DIR__.'/../resources/assets';
}
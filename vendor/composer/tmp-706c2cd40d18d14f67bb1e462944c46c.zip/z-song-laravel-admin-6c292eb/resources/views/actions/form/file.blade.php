<div class="form-group">
    <label>{{ $label }}</label>
    <input type="file" class="{{$class}}" name="{{$name}}" {!! $attributes !!} />
    @include('admin::actions.form.help-block')
</div>

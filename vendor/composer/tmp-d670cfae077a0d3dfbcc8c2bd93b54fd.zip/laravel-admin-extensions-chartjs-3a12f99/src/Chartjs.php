<?php

namespace Encore\Chartjs;

use Encore\Admin\Extension;

class Chartjs extends Extension
{
    public $name = 'chartjs';

    public $assets = __DIR__.'/../resources/assets';
}